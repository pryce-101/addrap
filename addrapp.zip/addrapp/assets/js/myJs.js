
$(document).ready(function(){
	$('#loginForm').submit(function(e){
		e.preventDefault();
		$.ajax({
			type:"POST",
			url:"loginScript.php",
			data:$(this).serialize(),			
			success : function(data){
				if(data == 'Login'){
				window.location = "index.fhp";
			}else{
				$("#displayInfo").html("<p>Failed Login</p>")
			}
		}
		});
		//return false;
	});
	
});
//}