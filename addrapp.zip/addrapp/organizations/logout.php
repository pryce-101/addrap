<?php
//session start
session_start();

//check to see is session is set
if(isset($_SESSION['loggedin_name'])){

    //unset and destroy session 
unset($_SESSION['loggedin_name']);
session_destroy($_SESSION['loggedin_name']);
    
    
//once session variable is destroyed, direct user to login page for successully loging out.    
header('Location: ../index.php');
}


?>