<?php
session_start();
include("connection.php");

$rows = array();
$qry = mysqli_query($connect,"SELECT * FROM contacts order by name ASC");
if($qry){
while($r = mysqli_fetch_assoc($qry)){
       $rows[] = $r;

}
header('Content-type: application/json');
  echo json_encode($rows);
  
}

mysqli_close($connect);


?>