<?php

define('BASE_PATH', 'http://127.0.0.1/myapilocation');

include('connection.php');

//script to insert data in db

if($query){
	
	echo 'Contact Created Successfully';

}else{
 echo 'Failed. Try Again';

}






?>