<?php
//$connect ="";
$host = "localhost";	
$db = "addrap";	
$us = "root";	
$ps = "";	

$connect  = mysqli_connect($host,$us,$ps,$db) or die(mysqli_error($connect));

if(!$connect){
echo 'Connection Failed!';
}
?>