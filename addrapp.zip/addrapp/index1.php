 <?php 
 require_once("connection.php");
 
    
    $form_code = mysqli_real_escape_string($connect,$_POST['password']);
    
    //form validation (check if user has field required input fields)
    if(!$form_code){
     $response  = "Enter Code Please!";    
    }else{
      
   // query db for a match
    $query = mysqli_query($connect,"SELECT * FROM admin WHERE code ='$form_code && classification = 'admin'") or die(mysqli_error($connect));
    
        //check if there is an ocurance with the user crendentials
        $number_of_hits = mysqli_num_rows($query);
        //if there is a match, proceed and allow entry
            if($number_of_hits > 0){            
                while($rows = mysqli_fetch_assoc($query)){
                    //get contents from database that belongs to the user and store in session variables
					session_start();
                    $_SESSION['real_name'] = $rows['name'];
                    $_SESSION['program'] = $rows['organization'];
                                
                   
                    //locate user to this page since login is successfull
                header ('Location: home/index.php');
                
                }
            
            }else{
            $query = mysqli_query(connect,"SELECT * FROM admin WHERE code ='$form_code && classification = 'sub-admin'") or die(mysqli_error($connect));
    
        //check if there is an ocurance with the user crendentials
        $number_of_hits = mysqli_num_rows($query);
        //if there is a match, proceed and allow entry
            if($number_of_hits > 0){
            
               while($rows = mysqli_fetch_assoc($query)){
                    //get contents from database that belongs to the user and store in session variables
                    $_SESSION['real_name'] = $rows['name'];
                    $_SESSION['program'] = $rows['organization'];
                    
                    //locate user to this page since login is successfull
                header ('Location: subAdmin/index.php');
                
                }
            
            }else{
               
                    $response = "Login failed. Try Again";
  
                   }    
                      
            }
	
        mysqli_close($connect); 
        }